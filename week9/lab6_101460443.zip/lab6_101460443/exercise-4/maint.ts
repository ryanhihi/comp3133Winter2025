import { Customer } from './customer';

let customer = new Customer("Ryan", "Gin", 20);
customer.greeter();