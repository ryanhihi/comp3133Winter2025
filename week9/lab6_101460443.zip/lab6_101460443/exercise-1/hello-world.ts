var greeter = function(name) {
    console.log('Hello '+ name);
}

greeter("Ryan Tran");