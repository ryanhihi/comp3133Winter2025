const Movie = require('./models/Movie');

const movieResolver = {
    Query: {
        getAllMovies: async () => {
            try {
                return await Movie.find(); // Corrected typo
            } catch (error) {
                throw new Error(`Error fetching movies: ${error.message}`);
            }
        },

        getMovieById: async (_, { eid }) => { // Renamed __dirname to _
            try {
                const movie = await Movie.findById(eid);
                if (!movie) throw new Error("Movie not found");
                return movie;
            } catch (error) {
                throw new Error(`Error fetching movie: ${error.message}`);
            }
        },
    },

    Mutation: {
        insertMovie: async (_, { name, director_name, production_house, release_date, rating }) => {
            try {
                const newMovie = new Movie({
                    name,
                    director_name,
                    production_house,
                    release_date,
                    rating,
                });

                return await newMovie.save();
            } catch (error) {
                throw new Error(`Error adding movie: ${error.message}`); // Updated error message
            }
        },

        updateById: async (_, { eid, ...updatedData }) => {
            try {
                const updatedMovie = await Movie.findByIdAndUpdate(eid, updatedData, { new: true });
                if (!updatedMovie) throw new Error("Movie not found");
                return updatedMovie;
            } catch (error) {
                throw new Error(`Error updating movie: ${error.message}`);
            }
        },

        deleteById: async (_, { eid }) => {
            try {
              const deletedMovie = await Movie.findByIdAndDelete(eid);
              if (!deletedMovie) throw new Error("No movie found");
              return deletedMovie; 
            } catch (error) {
              throw new Error(`Error deleting movie: ${error.message}`);
            }
          }
          
    },
};

module.exports = movieResolver;
